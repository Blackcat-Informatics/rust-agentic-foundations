---
# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: CC-BY-4.0
type: Assessment
id: assessment:census-debt-ratchet-explanation
subject: cap:census-debt-ratchet#explanation
inputs:
  - kind: section
    name: cap:census-debt-ratchet#explanation
    digest: 00a40f751a917df9578d6646c0a70547c6c3f33d3b2bda7b8d47ac36db6159fc
verdict: accepted
by: agent
---
