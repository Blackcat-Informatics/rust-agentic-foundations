---
# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: CC-BY-4.0
type: Assessment
id: assessment:workplan-strict-usage
subject: cap:workplan-strict#usage
inputs:
  - kind: section
    name: cap:workplan-strict#usage
    digest: 6cbaca2677db5b269c81fc2dd60c70ae7def0190e787d5fea309ba8f521befd1
  - kind: symbol
    name: raf_workplan::Gate::strict
    digest: 10c8ce32a3eaa5ecdece31c6158f9754acbca0e1389d0ca3ea675e93a401aecb
  - kind: symbol
    name: raf_workplan::Gate::strictness
    digest: 66f64d6c8410f09fa025eac851173611db8837b4307c6399757939128d68c022
  - kind: symbol
    name: raf_workplan::Workplan::claims_report
    digest: 2748fc418a9fce971231440c045a1941d7cf574703fd6f4e95ba0342868b0bc0
  - kind: symbol
    name: raf_workplan::Workplan::lines_report
    digest: a6645d4de16bc44fb10b687598fbff5678729813feb02a1b3474adf45ca488a3
  - kind: symbol
    name: raf_workplan::Workplan::strictness
    digest: 27d43ac06d3227b68d73aee75d13da0151e95f0cd90064cdaa906634daef0a5f
  - kind: symbol
    name: raf_workplan::Workplan::with_strictness
    digest: '0b9f967c1555717fdc85901e3f71f253ff7bc69b328f22030b2b056cce32c842'
  - kind: symbol
    name: raf_workplan::coverage::lines
    digest: 58042fdb90828289f23acca292cb4512771cf6c4f6598d150b2f59b199174386
verdict: accepted
by: agent
---
