---
# SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
# SPDX-License-Identifier: CC-BY-4.0
type: Assessment
id: assessment:workplan-strict-constraints
subject: cap:workplan-strict#constraints
inputs:
  - kind: section
    name: cap:workplan-strict#constraints
    digest: 6dd94fe378b979cb755d13f278e354e6beaf3dd56d0a45998e89a83dd67095a2
  - kind: symbol
    name: raf_okf::Strictness
    digest: 332c6dfe7b8130198e6e48680bf0789dc7034540dc2ff5c5054244e3cc43f67b
  - kind: symbol
    name: raf_workplan::Gate::record_options
    digest: fcb708722e6060f4a916caf1e559a2ba2beea46f34f713081e7142892a64bbbe
  - kind: symbol
    name: raf_workplan::Gate::strict
    digest: 10c8ce32a3eaa5ecdece31c6158f9754acbca0e1389d0ca3ea675e93a401aecb
  - kind: symbol
    name: raf_workplan::Gate::strictness
    digest: 66f64d6c8410f09fa025eac851173611db8837b4307c6399757939128d68c022
  - kind: symbol
    name: raf_workplan::Gate::write_debt
    digest: 72098f94cf37158ce207cdb00cfeaf53709a4c7ce63f8e166558181709bd96e0
  - kind: symbol
    name: raf_workplan::Opened::strictness_floor
    digest: fcc7fc6a3ffd4ade11f24e12b9a9e2f9aaadf4c84c63d797cf42619a3eb3a9af
  - kind: symbol
    name: raf_workplan::Opened::write_debt
    digest: 65e22abbfa20a5dc5af2e8434868d7445fe3d25079732b03c6788a7ef17b8298
  - kind: symbol
    name: raf_workplan::Workplan::claims_report
    digest: 2748fc418a9fce971231440c045a1941d7cf574703fd6f4e95ba0342868b0bc0
  - kind: symbol
    name: raf_workplan::Workplan::lines_report
    digest: a6645d4de16bc44fb10b687598fbff5678729813feb02a1b3474adf45ca488a3
  - kind: symbol
    name: raf_workplan::Workplan::strictness
    digest: 27d43ac06d3227b68d73aee75d13da0151e95f0cd90064cdaa906634daef0a5f
  - kind: symbol
    name: raf_workplan::Workplan::with_strictness
    digest: '0b9f967c1555717fdc85901e3f71f253ff7bc69b328f22030b2b056cce32c842'
  - kind: symbol
    name: raf_workplan::coverage::lines
    digest: 58042fdb90828289f23acca292cb4512771cf6c4f6598d150b2f59b199174386
  - kind: symbol
    name: raf_workplan::coverage::render::claims_json
    digest: 52290e6542bcc97dc9dc9fb47557ad6170f805f3bd967b7efb32f57e9d0e76c3
  - kind: symbol
    name: raf_workplan::coverage::render::claims_table
    digest: e4ca5d5383b7ab80f387f92fe08f7d23b78b7dcf7c317cc4d21cee9485b95dd3
  - kind: symbol
    name: raf_workplan::coverage::render::lines_json
    digest: c845ed06c4bc57c3b60ca9888fcdf1b549279d38c721802422c1827a8285ff13
  - kind: symbol
    name: raf_workplan::coverage::render::lines_table
    digest: 5a1a96f3a13d39e05b30eb7f6379e97c07b90ab278cd30c2a75e66344965b725
  - kind: symbol
    name: raf_workplan::debt
    digest: 59f77a2df7ef70a9b6d383f918481999a071ab58eaa9d1515c0748b22e8cad1d
  - kind: symbol
    name: raf_workplan::obligation::Touch
    digest: ca407531ac5b02455378a18b4a8188e2007434ae9f0c34e07bd4b5fc23d8c499
  - kind: symbol
    name: raf_workplan::obligation::Touched
    digest: ae57f2bd96ea153dc8b2936b97d47898ab8e26bd5cb8cd730d2823f4a3bf860d
  - kind: symbol
    name: raf_workplan::strict
    digest: 875c634e4115fc506798e85f7c91d589ac1e087241839b1db217934ef1d0769b
verdict: accepted
by: agent
---
