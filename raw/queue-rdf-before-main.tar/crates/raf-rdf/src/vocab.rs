// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Stable namespace laws; domain registries enumerate their closed shapes.

/// The IRI-versioned shared report vocabulary.
pub const REPORT: &str = "https://blackcatinformatics.ca/raf/report/1#";
/// Snapshot namespace, followed by a complete lowercase BLAKE3 digest.
pub const BASE: &str = "https://blackcatinformatics.ca/.well-known/genid/raf-report/";
/// RDF structural vocabulary.
pub const RDF: &str = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
/// XML Schema datatype vocabulary.
pub const XSD: &str = "http://www.w3.org/2001/XMLSchema#";
/// RDF class membership.
pub const TYPE: &str = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type";
/// Named statement provenance over a depth-one triple term.
pub const REIFIES: &str = "http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies";
