// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Ground terms; the type of a quoted statement prevents recursive nesting.

use crate::{Error, vocab};
use purrdf_lex::terminals;

/// An absolute IRI or a snapshot-owned root/fragment before BASE expansion.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Iri {
    pub(crate) text: String,
    pub(crate) local: bool,
}

impl Iri {
    /// Construct an absolute IRI.
    ///
    /// # Errors
    /// Refuses a missing scheme, forbidden IRI characters or malformed percent escapes.
    pub fn absolute(text: impl Into<String>) -> Result<Self, Error> {
        let text = text.into();
        let scheme = text.split_once(':').map(|(scheme, _)| scheme);
        let valid = scheme.is_some_and(|scheme| {
            scheme.starts_with(|c: char| c.is_ascii_alphabetic())
                && scheme.bytes().all(|b| b.is_ascii_alphanumeric() || b"+-.".contains(&b))
        });
        if !valid || text.chars().any(terminals::is_iriref_forbidden) || !percent_valid(&text) {
            return Err(Error::Value(format!("absolute IRI {text}")));
        }
        Ok(Self { text, local: false })
    }

    /// Construct the snapshot root (`""`) or a named fragment (`"#name"`).
    ///
    /// # Errors
    /// Refuses other relative IRIs, an empty fragment, unsafe bytes or malformed escapes.
    pub fn local(text: impl Into<String>) -> Result<Self, Error> {
        let text = text.into();
        if !text.is_empty() && (!text.starts_with('#') || text.len() == 1
            || !text.as_bytes()[1..].iter().all(|b| b.is_ascii_alphanumeric() || b"-._~!$&'()*+,;=:@/?%".contains(b))
            || !percent_valid(&text)) {
            return Err(Error::Value(format!("snapshot fragment {text}")));
        }
        Ok(Self { text, local: true })
    }

    /// The stored absolute or snapshot-relative spelling.
    pub fn as_str(&self) -> &str { &self.text }

    /// Whether the snapshot BASE supplies the absolute prefix.
    pub fn is_local(&self) -> bool { self.local }
}

fn percent_valid(text: &str) -> bool {
    let mut bytes = text.bytes();
    while let Some(byte) = bytes.next() {
        if byte == b'%' && !(bytes.next().is_some_and(|b| b.is_ascii_hexdigit())
            && bytes.next().is_some_and(|b| b.is_ascii_hexdigit())) {
            return false;
        }
    }
    true
}

/// An atomic RDF object, with no quoted statement or blank node.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Atom {
    /// Named resource.
    Iri(Iri),
    /// Literal lexical form with an absolute datatype IRI.
    Literal {
        /// Exact lexical form; numeric domain validation belongs to the consumer.
        lexical: String,
        /// Datatype IRI.
        datatype: Iri,
    },
}

impl Atom {
    /// A string literal.
    pub fn string(text: impl Into<String>) -> Self {
        Self::Literal { lexical: text.into(), datatype: Iri { text: format!("{}string", vocab::XSD), local: false } }
    }

    /// An integer literal from its decimal display.
    pub fn integer(value: impl std::fmt::Display) -> Result<Self, Error> {
        let lexical = value.to_string();
        let digits = lexical.strip_prefix('-').unwrap_or(&lexical);
        if digits.is_empty() || !digits.bytes().all(|b| b.is_ascii_digit())
            || (digits.len() > 1 && digits.starts_with('0')) || lexical == "-0" {
            return Err(Error::Value(format!("canonical integer {lexical}")));
        }
        Ok(Self::Literal { lexical, datatype: Iri { text: format!("{}integer", vocab::XSD), local: false } })
    }

    /// A boolean literal.
    pub fn boolean(value: bool) -> Self {
        Self::Literal { lexical: value.to_string(), datatype: Iri { text: format!("{}boolean", vocab::XSD), local: false } }
    }

    pub(crate) fn validate(&self) -> Result<(), Error> {
        if let Self::Literal { datatype, .. } = self && datatype.local {
            return Err(Error::Value("a literal datatype must be absolute".into()));
        }
        Ok(())
    }
}

/// A quoted ground statement whose atomic object makes nesting depth one.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Statement {
    /// Named subject.
    pub subject: Iri,
    /// Absolute predicate.
    pub predicate: Iri,
    /// Atomic object.
    pub object: Atom,
}

/// An atomic object or one quoted statement.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Object {
    /// Ordinary atomic value.
    Atom(Atom),
    /// RDF 1.2 triple term, used by named reifiers.
    Triple(Statement),
}

impl From<Atom> for Object {
    fn from(atom: Atom) -> Self { Self::Atom(atom) }
}

/// One ground RDF triple. Report subjects are snapshot-owned named nodes.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Triple {
    /// Snapshot root or named fragment.
    pub subject: Iri,
    /// Absolute predicate IRI.
    pub predicate: Iri,
    /// Atomic value or depth-one quoted statement.
    pub object: Object,
}

impl Triple {
    pub(crate) fn validate(&self) -> Result<(), Error> {
        if !self.subject.local || self.predicate.local {
            return Err(Error::Value("report subjects must be owned; predicates must be absolute".into()));
        }
        match &self.object {
            Object::Atom(atom) => atom.validate(),
            Object::Triple(statement) => {
                if statement.predicate.local {
                    return Err(Error::Value("quoted predicate must be absolute".into()));
                }
                statement.object.validate()
            }
        }
    }
}
