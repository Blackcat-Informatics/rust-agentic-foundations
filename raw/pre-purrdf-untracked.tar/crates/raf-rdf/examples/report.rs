// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0
//! A closed ground report with typed fields and named statement provenance.
use raf_rdf::{Atom, Format, Graph, Iri, Object, Statement, Triple, vocab};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut graph = Graph::new();
    let root = Iri::local("")?;
    let predicate = Iri::absolute("urn:example:value")?;
    for atom in [
        Atom::string("é雪\n\0\"\\\u{85}"),
        Atom::string("literal \\u0085"),
        Atom::integer(123)?,
        Atom::boolean(true),
        Atom::Literal {
            lexical: "\tcustom".into(),
            datatype: Iri::absolute("urn:example:datatype")?,
        },
    ] {
        graph.insert(Triple {
            subject: root.clone(),
            predicate: predicate.clone(),
            object: atom.into(),
        })?;
    }
    let proof = Iri::local("#proof")?;
    graph.insert(Triple {
        subject: root.clone(),
        predicate: Iri::absolute("urn:example:proof")?,
        object: Atom::Iri(proof.clone()).into(),
    })?;
    graph.insert(Triple {
        subject: proof,
        predicate: Iri::absolute(vocab::REIFIES)?,
        object: Object::Triple(Statement {
            subject: root,
            predicate,
            object: Atom::integer(123)?,
        }),
    })?;
    let mut args = std::env::args().skip(1);
    let format = match args.next().as_deref() {
        None => Format::Turtle,
        Some("nt") => Format::NTriples,
        Some(_) => return Err("usage: report [nt]".into()),
    };
    if args.next().is_some() {
        return Err("usage: report [nt]".into());
    }
    print!("{}", graph.to_text(format)?);
    Ok(())
}
