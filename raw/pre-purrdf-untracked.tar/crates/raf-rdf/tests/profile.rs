// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Canonical profile, identity, term validation and refusal neighbors.

use raf_rdf::{Atom, Error, Format, Graph, Iri, Object, Statement, Triple, vocab};

fn absolute(value: &str) -> Iri {
    Iri::absolute(value).unwrap()
}
fn local(value: &str) -> Iri {
    Iri::local(value).unwrap()
}
fn triple(subject: &str, object: impl Into<Object>) -> Triple {
    Triple {
        subject: local(subject),
        predicate: absolute("urn:predicate"),
        object: object.into(),
    }
}
fn example() -> Graph {
    let mut graph = Graph::new();
    // Insert the fragment before the root: output still starts at the root.
    graph
        .insert(triple("#node", Atom::string("é\n\0\"\\\u{85}")))
        .unwrap();
    graph.insert(triple("", Atom::Iri(local("#node")))).unwrap();
    graph
        .insert(Triple {
            subject: local("#proof"),
            predicate: absolute(vocab::REIFIES),
            object: Object::Triple(Statement {
                subject: local(""),
                predicate: absolute("urn:predicate"),
                object: Atom::Iri(local("#node")),
            }),
        })
        .unwrap();
    for (key, atom) in [
        ("#integer", Atom::integer(123).unwrap()),
        ("#boolean", Atom::boolean(true)),
        (
            "#typed",
            Atom::Literal {
                lexical: "\tcustom雪".into(),
                datatype: absolute("urn:datatype"),
            },
        ),
    ] {
        graph.insert(triple(key, atom)).unwrap();
    }
    graph
}

#[test]
fn formats_round_trip_the_same_graph_and_snapshot_in_canonical_order() {
    let graph = example();
    let snapshot = graph.snapshot().unwrap();
    let mut reverse = Graph::new();
    for triple in graph
        .triples()
        .cloned()
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
    {
        reverse.insert(triple).unwrap();
    }
    for format in [Format::Turtle, Format::NTriples] {
        let text = graph.to_text(format).unwrap();
        assert_eq!(text, reverse.to_text(format).unwrap());
        assert_eq!(Graph::from_text(&text, format).unwrap(), graph);
        assert_eq!(
            Graph::from_text(&text, format).unwrap().snapshot().unwrap(),
            snapshot
        );
        if format == Format::NTriples {
            assert!(text.starts_with(&format!("<{snapshot}> ")));
        }
    }
    let mut changed = graph.clone();
    changed
        .insert(triple("", Atom::string("a changed fact")))
        .unwrap();
    assert_ne!(changed.snapshot().unwrap(), snapshot);
}

#[test]
fn absolute_iris_use_component_validation_without_normalizing_identity() {
    for value in [
        "https://[",
        "urn:a[b",
        "urn:a#b#c",
        "urn:a%",
        "urn:a%GG",
        "urn:a\u{7f}",
        "urn:a\u{85}",
        "relative",
        "1bad:a",
    ] {
        assert!(Iri::absolute(value).is_err(), "{value:?}");
    }
    for value in [
        "https://[::1]/é",
        "urn:example:a",
        "https://example.org/a%FF",
        "https://example.org/%2f",
        "https://example.org/雪",
    ] {
        assert_eq!(Iri::absolute(value).unwrap().as_str(), value);
    }
    assert_ne!(absolute("urn:a%2f"), absolute("urn:a%2F"));
}

#[test]
fn literal_language_metadata_and_relative_datatypes_are_refused_in_both_roles() {
    for datatype in [
        local("#datatype"),
        absolute(&format!("{}langString", vocab::RDF)),
        absolute(&format!("{}dirLangString", vocab::RDF)),
    ] {
        let atom = Atom::Literal {
            lexical: "value".into(),
            datatype,
        };
        assert!(Graph::new().insert(triple("", atom.clone())).is_err());
        assert!(
            Graph::new()
                .insert(triple(
                    "",
                    Object::Triple(Statement {
                        subject: absolute("urn:subject"),
                        predicate: absolute("urn:predicate"),
                        object: atom
                    })
                ))
                .is_err()
        );
    }
    for datatype in [
        absolute(&format!("{}string", vocab::XSD)),
        absolute("urn:datatype"),
    ] {
        let mut graph = Graph::new();
        graph
            .insert(triple(
                "",
                Atom::Literal {
                    lexical: "value".into(),
                    datatype,
                },
            ))
            .unwrap();
        assert!(graph.to_text(Format::Turtle).is_ok());
    }
}

#[test]
fn missing_root_dangling_references_duplicates_and_relative_predicates_refuse() {
    let mut graph = Graph::new();
    graph
        .insert(triple("#node", Atom::string("orphan root")))
        .unwrap();
    assert!(graph.to_text(Format::Turtle).is_err());
    for object in [
        Object::Atom(Atom::Iri(local("#absent"))),
        Object::Triple(Statement {
            subject: local("#absent"),
            predicate: absolute("urn:p"),
            object: Atom::string("v"),
        }),
        Object::Triple(Statement {
            subject: local(""),
            predicate: absolute("urn:p"),
            object: Atom::Iri(local("#absent")),
        }),
    ] {
        let mut graph = Graph::new();
        graph.insert(triple("", object)).unwrap();
        assert!(graph.to_text(Format::Turtle).is_err());
        graph
            .insert(triple("#absent", Atom::string("present")))
            .unwrap();
        assert!(graph.to_text(Format::Turtle).is_ok());
    }
    let valid = triple("", Atom::string("value"));
    let mut graph = Graph::new();
    graph.insert(valid.clone()).unwrap();
    assert_eq!(graph.insert(valid.clone()), Err(Error::Repeated));
    assert!(
        graph
            .insert(Triple {
                subject: absolute("urn:foreign"),
                ..valid.clone()
            })
            .is_err()
    );
    assert!(
        graph
            .insert(Triple {
                predicate: local("#predicate"),
                ..valid
            })
            .is_err()
    );
}

#[test]
fn canonical_bytes_include_cr_and_final_lf_and_reject_alternate_escapes() {
    for format in [Format::Turtle, Format::NTriples] {
        let text = example().to_text(format).unwrap();
        assert!(matches!(
            Graph::from_text(&text.replace('\n', "\r\n"), format),
            Err(Error::NotCanonical { line: 1 })
        ));
        assert!(
            matches!(Graph::from_text(text.strip_suffix('\n').unwrap(), format), Err(Error::NotCanonical { line }) if line == text.lines().count())
        );
        for altered in [
            format!("{text}\n"),
            format!(" {text}"),
            text.replace("é", "\\u00E9"),
            text.replace(" .\n", "  .\n"),
        ] {
            assert!(matches!(
                Graph::from_text(&altered, format),
                Err(Error::NotCanonical { .. })
            ));
        }
        assert_eq!(Graph::from_text(&text, format).unwrap(), example());
    }
}

#[test]
fn malformed_syntax_digest_and_ownership_have_valid_neighbors() {
    let graph = example();
    for format in [Format::Turtle, Format::NTriples] {
        let text = graph.to_text(format).unwrap();
        for altered in [
            text.replace("\\n", "\\q"),
            text.replace("é", "\\uD800"),
            text.replace("é", "\\U00110000"),
            text.replace("é", "\\u12"),
            text.replace("urn:predicate", "https://["),
            text.replace("urn:predicate", "#relative"),
            text.replace("\"123\"", "\"124\""),
            text.replace("#node>", "#missing>"),
        ] {
            assert!(Graph::from_text(&altered, format).is_err(), "{altered}");
        }
        assert!(Graph::from_text("", format).is_err());
        assert!(
            Graph::from_text(
                &text,
                if format == Format::Turtle {
                    Format::NTriples
                } else {
                    Format::Turtle
                }
            )
            .is_err()
        );
        assert_eq!(Graph::from_text(&text, format).unwrap(), graph);
    }
}

#[test]
fn abbreviations_blank_nodes_and_quads_are_outside_the_closed_profile() {
    let graph = example();
    for format in [Format::Turtle, Format::NTriples] {
        let text = graph.to_text(format).unwrap();
        let root = if format == Format::Turtle {
            "<>".to_owned()
        } else {
            format!("<{}>", graph.snapshot().unwrap())
        };
        for altered in [
            format!("PREFIX p: <urn:>\n{text}"),
            text.replacen(&root, "_:root", 1),
            text.replacen("<urn:predicate>", "p:predicate", 1),
            text.replacen(" .\n", " <urn:graph> .\n", 1),
        ] {
            assert_ne!(altered, text);
            assert!(Graph::from_text(&altered, format).is_err(), "{altered}");
        }
        assert_eq!(Graph::from_text(&text, format).unwrap(), graph);
    }
}

#[test]
fn ground_validation_does_not_apply_domain_shapes_or_datatype_value_spaces() {
    let mut graph = Graph::new();
    graph
        .insert(Triple {
            subject: local(""),
            predicate: absolute("urn:application:unregistered-property"),
            object: Atom::Literal {
                lexical: "not a number".into(),
                datatype: absolute(&format!("{}integer", vocab::XSD)),
            }
            .into(),
        })
        .unwrap();
    for format in [Format::Turtle, Format::NTriples] {
        let text = graph.to_text(format).unwrap();
        assert_eq!(Graph::from_text(&text, format).unwrap(), graph);
    }
}

#[test]
fn an_external_iri_sharing_a_snapshot_prefix_is_not_local() {
    let mut graph = Graph::new();
    let external = format!("{}{}suffix", vocab::BASE, "a".repeat(64));
    graph
        .insert(triple("", Atom::Iri(absolute(&external))))
        .unwrap();
    let text = graph.to_text(Format::NTriples).unwrap();
    assert_eq!(Graph::from_text(&text, Format::NTriples).unwrap(), graph);
    assert!(text.contains(&format!("<{external}>")));
}

#[test]
fn both_readers_refuse_language_datatypes_literal_subjects_and_nested_terms() {
    for format in [Format::Turtle, Format::NTriples] {
        let text = example().to_text(format).unwrap();
        for name in ["langString", "dirLangString"] {
            let altered = text.replace("urn:datatype", &format!("{}{name}", vocab::RDF));
            assert!(
                matches!(Graph::from_text(&altered, format), Err(Error::Value(reason)) if reason.contains("language metadata"))
            );
        }
        let first_subject = if format == Format::Turtle {
            "<>".to_owned()
        } else {
            format!("<{}>", example().snapshot().unwrap())
        };
        let altered = text.replacen(
            &format!("{first_subject} <urn:predicate>"),
            "\"literal subject\" <urn:predicate>",
            1,
        );
        assert_ne!(altered, text);
        assert!(matches!(
            Graph::from_text(&altered, format),
            Err(Error::Syntax { .. })
        ));
        let altered = text.replace("<<( ", "<<( <<( ");
        assert_ne!(altered, text);
        assert!(Graph::from_text(&altered, format).is_err());
        assert_eq!(Graph::from_text(&text, format).unwrap(), example());
    }
}

#[test]
fn independent_parser_pins_preserve_typed_literals_controls_and_triple_terms() {
    let turtle = include_str!("fixtures/profile.ttl");
    let nt = include_str!("fixtures/profile.nt");
    let graph = Graph::from_text(turtle, Format::Turtle).unwrap();
    assert_eq!(Graph::from_text(nt, Format::NTriples).unwrap(), graph);
    assert!(graph.triples().any(|t| matches!(&t.object, Object::Atom(Atom::Literal { lexical, datatype }) if lexical.contains('\0') && datatype.as_str().ends_with("#string"))));
    assert!(graph.triples().any(|t| matches!(&t.object, Object::Triple(Statement { object: Atom::Literal { lexical, datatype }, .. }) if lexical == "123" && datatype.as_str().ends_with("#integer"))));
    let mut triples: Vec<_> = nt.lines().collect();
    triples.sort_unstable();
    // The independent serializer escapes C1; the shared canonical literal
    // carrier emits U+0085 verbatim. Both spellings denote the same scalar.
    let compared = format!("{}\n", triples.join("\n")).replace('\u{85}', "\\u0085");
    assert_eq!(compared, include_str!("fixtures/profile.oracle.nt"));
    assert!(graph.triples().any(|t| matches!(&t.object, Object::Atom(Atom::Literal { lexical, .. }) if lexical == "literal \\u0085")));
}
