// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! One owned graph with borrowed iteration and deterministic term ordering.

use std::collections::BTreeSet;

use crate::{Atom, Error, Format, Iri, Object, Triple, read, write};

/// A duplicate-free, ordered ground report graph.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Graph {
    pub(crate) triples: BTreeSet<Triple>,
}

impl Graph {
    /// An empty graph, to be populated before rendering.
    pub fn new() -> Self {
        Self::default()
    }

    /// Insert one statement, checking term roles and refusing duplicates.
    ///
    /// # Errors
    /// Refuses a non-owned subject, relative predicate/datatype or duplicate triple.
    pub fn insert(&mut self, triple: Triple) -> Result<(), Error> {
        triple.validate()?;
        if !self.triples.insert(triple) {
            return Err(Error::Repeated);
        }
        Ok(())
    }

    /// The ordered statements, borrowed without rebuilding the graph.
    pub fn triples(&self) -> impl Iterator<Item = &Triple> {
        self.triples.iter()
    }

    /// Consume the graph, moving terms into a domain-specific validated index.
    pub fn into_triples(self) -> impl Iterator<Item = Triple> {
        self.triples.into_iter()
    }

    /// Validate root and owned references, then render one canonical format.
    ///
    /// # Errors
    /// Refuses a missing root or a reference to an absent owned node.
    pub fn to_text(&self, format: Format) -> Result<String, Error> {
        self.validate()?;
        Ok(write::render(self, format))
    }

    /// Read exactly one canonical, closed report profile.
    ///
    /// # Errors
    /// Refuses unsupported syntax, duplicate/dangling statements, an incorrect
    /// digest, a foreign subject or any noncanonical byte spelling.
    pub fn from_text(text: &str, format: Format) -> Result<Self, Error> {
        read::parse(text, format)
    }

    /// Full BLAKE3 snapshot identity, independent of the selected output format.
    ///
    /// # Errors
    /// Refuses an invalid root or owned reference.
    pub fn snapshot(&self) -> Result<String, Error> {
        self.validate()?;
        Ok(write::base(self))
    }

    pub(crate) fn validate(&self) -> Result<(), Error> {
        let subjects: BTreeSet<&Iri> = self.triples.iter().map(|t| &t.subject).collect();
        if !subjects.iter().any(|iri| iri.as_str().is_empty()) {
            return Err(Error::Value("the report root is absent".into()));
        }
        let check = |iri: &Iri| {
            if iri.is_local() && !subjects.contains(iri) {
                Err(Error::Value(format!(
                    "dangling owned node {}",
                    iri.as_str()
                )))
            } else {
                Ok(())
            }
        };
        for triple in &self.triples {
            triple.validate()?;
            match &triple.object {
                Object::Atom(Atom::Iri(iri)) => check(iri)?,
                Object::Atom(Atom::Literal { .. }) => {}
                Object::Triple(statement) => {
                    check(&statement.subject)?;
                    if let Atom::Iri(iri) = &statement.object {
                        check(iri)?;
                    }
                }
            }
        }
        Ok(())
    }
}
