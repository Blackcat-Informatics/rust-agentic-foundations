// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Bounded-depth reader of the two canonical profiles, using shared lexical laws.

use purrdf_lex::{term_syntax, terminals};

use crate::{Atom, Error, Format, Graph, Iri, Object, Statement, Triple, vocab, write};

struct Parser<'a> {
    text: &'a str,
    at: usize,
}

impl Parser<'_> {
    fn error(&self, reason: impl Into<String>) -> Error {
        let head = &self.text[..self.at];
        Error::Syntax {
            line: head.bytes().filter(|b| *b == b'\n').count() + 1,
            column: head.rsplit('\n').next().unwrap_or("").chars().count() + 1,
            reason: reason.into(),
        }
    }

    fn ws(&mut self) {
        self.at = terminals::skip_ws(self.text.as_bytes(), self.at);
    }

    fn take(&mut self, token: &str) -> bool {
        self.ws();
        if self.text[self.at..].starts_with(token) {
            self.at += token.len();
            true
        } else {
            false
        }
    }

    fn need(&mut self, token: &str) -> Result<(), Error> {
        if self.take(token) {
            Ok(())
        } else {
            Err(self.error(format!("expected {token}")))
        }
    }

    fn quoted(&mut self, close: char) -> Result<String, Error> {
        let mut out = String::new();
        loop {
            let ch = self.text[self.at..]
                .chars()
                .next()
                .ok_or_else(|| self.error("unterminated term"))?;
            if ch == close {
                self.at += ch.len_utf8();
                return Ok(out);
            }
            if ch == '\\' {
                let tail = &self.text.as_bytes()[self.at..];
                if matches!(tail.get(1), Some(b'u' | b'U')) {
                    let (value, len) = terminals::decode_uchar(tail)
                        .map_err(|e| self.error(format!("invalid UCHAR: {e:?}")))?;
                    out.push(value);
                    self.at += len;
                } else if close == '"' {
                    out.push(
                        tail.get(1)
                            .and_then(|b| terminals::echar_value(*b))
                            .ok_or_else(|| self.error("invalid ECHAR"))?,
                    );
                    self.at += 2;
                } else {
                    return Err(self.error("IRI escape must be UCHAR"));
                }
            } else {
                if (close == '>' && terminals::is_iriref_forbidden(ch))
                    || (close == '"' && matches!(ch, '\n' | '\r'))
                {
                    return Err(self.error("forbidden term character"));
                }
                out.push(ch);
                self.at += ch.len_utf8();
            }
        }
    }

    fn iri(&mut self) -> Result<Iri, Error> {
        self.need("<")?;
        let text = self.quoted('>')?;
        if text.is_empty() || text.starts_with('#') {
            Iri::local(text)
        } else {
            Iri::absolute(text)
        }
    }

    fn atom(&mut self) -> Result<Atom, Error> {
        if self.take("\"") {
            let lexical = self.quoted('"')?;
            if self.take("^^") {
                Ok(Atom::Literal {
                    lexical,
                    datatype: self.iri()?,
                })
            } else {
                Ok(Atom::string(lexical))
            }
        } else {
            Ok(Atom::Iri(self.iri()?))
        }
    }

    fn object(&mut self) -> Result<Object, Error> {
        if self.take(term_syntax::TRIPLE_TERM_OPEN) {
            let statement = Statement {
                subject: self.iri()?,
                predicate: self.iri()?,
                object: self.atom()?,
            };
            self.need(term_syntax::TRIPLE_TERM_CLOSE)?;
            Ok(Object::Triple(statement))
        } else {
            Ok(Object::Atom(self.atom()?))
        }
    }

    fn triple(&mut self) -> Result<Triple, Error> {
        let triple = Triple {
            subject: self.iri()?,
            predicate: self.iri()?,
            object: self.object()?,
        };
        self.need(".")?;
        Ok(triple)
    }
}

fn checked_base(text: String) -> Result<String, Error> {
    let hash = text
        .strip_prefix(vocab::BASE)
        .ok_or_else(|| Error::Value("snapshot BASE namespace".into()))?;
    if hash.len() != 64
        || !hash
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err(Error::Value(
            "snapshot BASE requires 64 lowercase hexadecimal digits".into(),
        ));
    }
    Ok(text)
}

fn owned(iri: &mut Iri, base: &str, format: Format) -> Result<(), Error> {
    match format {
        Format::Turtle => {}
        Format::NTriples if iri.local => {
            return Err(Error::Value("N-Triples requires absolute IRIs".into()));
        }
        Format::NTriples => {
            if iri.text == base {
                *iri = Iri::local("")?;
            } else if let Some(fragment) = iri
                .text
                .strip_prefix(base)
                .filter(|tail| tail.starts_with('#'))
            {
                // A complete root or its fragment is owned. Merely sharing
                // a textual prefix never makes an external IRI local.
                *iri = Iri::local(fragment)?;
            }
        }
    }
    Ok(())
}

fn normalize(triple: &mut Triple, base: &str, format: Format) -> Result<(), Error> {
    owned(&mut triple.subject, base, format)?;
    let atom = |value: &mut Atom| match value {
        Atom::Iri(iri) => owned(iri, base, format),
        Atom::Literal { datatype, .. } => {
            if datatype.local {
                Err(Error::Value("absolute datatype required".into()))
            } else {
                Ok(())
            }
        }
    };
    match &mut triple.object {
        Object::Atom(value) => atom(value)?,
        Object::Triple(statement) => {
            owned(&mut statement.subject, base, format)?;
            atom(&mut statement.object)?;
        }
    }
    Ok(())
}

pub(crate) fn parse(text: &str, format: Format) -> Result<Graph, Error> {
    let mut p = Parser { text, at: 0 };
    let base = match format {
        Format::Turtle => {
            p.need("VERSION")?;
            p.need("\"1.2\"")?;
            p.need("BASE")?;
            let base = p.iri()?;
            checked_base(base.text)?
        }
        Format::NTriples => {
            // Canonical order begins with the owned root's first statement.
            let before = p.at;
            let root = p.iri()?;
            if root.local {
                return Err(p.error("absolute root required"));
            }
            p.at = before;
            checked_base(root.text)?
        }
    };
    let mut graph = Graph::new();
    p.ws();
    while p.at < text.len() {
        let mut triple = p.triple()?;
        normalize(&mut triple, &base, format)?;
        graph.insert(triple)?;
        p.ws();
    }
    graph.validate()?;
    let computed = write::base(&graph);
    if computed != base {
        return Err(Error::Digest {
            declared: base,
            computed,
        });
    }
    let canonical = write::render(&graph, format);
    if canonical != text {
        let mut expected = canonical.split_inclusive('\n');
        let mut actual = text.split_inclusive('\n');
        let mut line = 1;
        loop {
            match (expected.next(), actual.next()) {
                (None, None) => break,
                (a, b) if a == b => line += 1,
                _ => return Err(Error::NotCanonical { line }),
            }
        }
    }
    Ok(graph)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ownership_normalization_checks_the_selected_root_boundary() {
        let base = format!("{}{}", vocab::BASE, "a".repeat(64));
        for (text, expected) in [(base.clone(), ""), (format!("{base}#node"), "#node")] {
            let mut iri = Iri::absolute(text).unwrap();
            owned(&mut iri, &base, Format::NTriples).unwrap();
            assert_eq!(iri, Iri::local(expected).unwrap());
        }
        for text in [
            format!("{base}suffix"),
            format!("{}{}#node", vocab::BASE, "b".repeat(64)),
        ] {
            let mut iri = Iri::absolute(&text).unwrap();
            owned(&mut iri, &base, Format::NTriples).unwrap();
            assert!(!iri.is_local());
            assert_eq!(iri.as_str(), text);
        }
        let mut empty_fragment = Iri::absolute(format!("{base}#")).unwrap();
        assert!(owned(&mut empty_fragment, &base, Format::NTriples).is_err());
    }
}
