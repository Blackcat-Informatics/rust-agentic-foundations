// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! A single normalized Turtle body supplies both formats' snapshot identity.

use purrdf_lex::term_syntax;

use crate::{Atom, Format, Graph, Iri, Object, vocab};

fn iri(iri: &Iri, base: Option<&str>, out: &mut String) {
    if iri.local
        && let Some(base) = base
    {
        // Append to the output directly, without allocating an expanded IRI.
        out.push('<');
        purrdf_lex::iri_escape::push_escaped(base, out);
        purrdf_lex::iri_escape::push_escaped(&iri.text, out);
        out.push('>');
    } else {
        term_syntax::write_iri(&iri.text, out);
    }
}

fn atom(value: &Atom, base: Option<&str>, out: &mut String) {
    match value {
        Atom::Iri(value) => iri(value, base, out),
        Atom::Literal { lexical, datatype } => {
            term_syntax::write_literal(lexical, datatype.as_str(), None, None, out);
        }
    }
}

fn body(graph: &Graph, base: Option<&str>, out: &mut String) {
    for triple in &graph.triples {
        iri(&triple.subject, base, out);
        out.push(' ');
        iri(&triple.predicate, base, out);
        out.push(' ');
        match &triple.object {
            Object::Atom(value) => atom(value, base, out),
            Object::Triple(statement) => {
                out.push_str(term_syntax::TRIPLE_TERM_OPEN);
                out.push(' ');
                iri(&statement.subject, base, out);
                out.push(' ');
                iri(&statement.predicate, base, out);
                out.push(' ');
                atom(&statement.object, base, out);
                out.push(' ');
                out.push_str(term_syntax::TRIPLE_TERM_CLOSE);
            }
        }
        out.push_str(" .\n");
    }
}

fn normalized(graph: &Graph) -> String {
    let mut out = String::from("VERSION \"1.2\"\n");
    body(graph, None, &mut out);
    out
}

pub(crate) fn base(graph: &Graph) -> String {
    format!(
        "{}{}",
        vocab::BASE,
        blake3::hash(normalized(graph).as_bytes()).to_hex()
    )
}

pub(crate) fn render(graph: &Graph, format: Format) -> String {
    // The exact normalized body is retained once for Turtle and its hash;
    // the graph and its terms are never cloned to change presentation.
    let mut normalized = normalized(graph);
    let base = format!(
        "{}{}",
        vocab::BASE,
        blake3::hash(normalized.as_bytes()).to_hex()
    );
    match format {
        Format::Turtle => {
            normalized.insert_str("VERSION \"1.2\"\n".len(), &format!("BASE <{base}>\n"));
            normalized
        }
        Format::NTriples => {
            drop(normalized);
            let mut out = String::new();
            body(graph, Some(&base), &mut out);
            out
        }
    }
}
