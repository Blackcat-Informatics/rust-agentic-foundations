// SPDX-FileCopyrightText: 2026 Blackcat Informatics® Inc. <paudley@blackcatinformatics.ca>
// SPDX-License-Identifier: MIT OR Apache-2.0 OR MulanPSL-2.0

//! Positive, deliberately narrow provenance for the standard format macro.

use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::mem::size_of;

use super::{Call, Formats, Import, ScopeKind};
use crate::RelPath;
use crate::facts::AttrFact;
use crate::index::{Index, UseKind};
use crate::item::{Namespace, SymbolKind};
use crate::resolve::Heads;
use crate::work::{self, Work};
use crate::workspace::SourceFile;

/// Context facts owned once by a reachability walk, not once per invocation.
#[derive(Debug)]
pub(in crate::reach) struct Resolver {
    disabled: Vec<bool>,
    uncertain_globs: Vec<bool>,
}

fn capture_macro(name: &str) -> bool {
    name == "format"
}

fn expression_macro(name: &str) -> bool {
    matches!(
        name,
        "format"
            | "format_args"
            | "print"
            | "println"
            | "eprint"
            | "eprintln"
            | "write"
            | "writeln"
            | "panic"
            | "assert"
            | "assert_eq"
            | "assert_ne"
            | "debug_assert"
            | "debug_assert_eq"
            | "debug_assert_ne"
            | "vec"
    )
}

fn endpoint(path: &[String], allowed: fn(&str) -> bool) -> bool {
    path.len() == 2 && path[0] == "std" && allowed(&path[1])
}

fn disables(attrs: &[AttrFact]) -> bool {
    attrs.iter().any(|attr| {
        work::add(Work::ReachFormatBytes, attr.path.len() + attr.args.len());
        matches!(
            attr.path.as_str(),
            "no_implicit_prelude" | "no_std" | "no_core" | "macro_use"
        ) || (attr.path == "cfg_attr"
            && attr
                .args
                .split(|ch: char| !ch.is_alphanumeric() && ch != '_')
                .any(|word| {
                    matches!(
                        word,
                        "no_implicit_prelude" | "no_std" | "no_core" | "macro_use"
                    )
                }))
    })
}

impl Resolver {
    pub(in crate::reach) fn new(index: &Index, files: &BTreeMap<RelPath, SourceFile>) -> Self {
        let mut disabled = vec![false; index.modules.len()];
        for file in files.values() {
            for reach in &file.reached {
                let root = index.target_roots[reach.target.index()];
                let Some(&module) = index.module_by_path.get(&(root, reach.module_path.clone()))
                else {
                    continue;
                };
                disabled[module] |= disables(&file.facts.attrs);
                let mut pending = vec![(module, &file.facts.body)];
                while let Some((module, body)) = pending.pop() {
                    work::add(Work::ReachFormatTokens, 1);
                    // macro_use can install names the source index does not inventory.
                    disabled[module] |= body.items.iter().any(|item| disables(&item.attrs));
                    for child in &body.mods {
                        disabled[module] |= child.attrs.iter().any(|attr| {
                            attr.path == "macro_use"
                                || (attr.path == "cfg_attr" && attr.args.contains("macro_use"))
                        });
                        let path = format!("{}::{}", index.modules[module].path, child.name);
                        let Some(&child_module) = index.module_by_path.get(&(root, path.into()))
                        else {
                            continue;
                        };
                        disabled[child_module] |= disables(&child.attrs);
                        if let Some(body) = &child.inline {
                            pending.push((child_module, body));
                        }
                    }
                }
            }
        }
        // Propagate attribute uncertainty to descendants without a per-call walk.
        let mut children = vec![Vec::new(); index.modules.len()];
        let mut queue = VecDeque::new();
        for (at, module) in index.modules.iter().enumerate() {
            if let Some(parent) = module.parent {
                children[parent].push(at);
            }
            if disabled[at] {
                queue.push_back(at);
            }
        }
        while let Some(module) = queue.pop_front() {
            for &child in &children[module] {
                work::add(Work::ReachFormatTokens, 1);
                if !disabled[child] {
                    disabled[child] = true;
                    queue.push_back(child);
                }
            }
        }
        let mut uncertain_globs = vec![false; index.modules.len()];
        let mut readers = vec![Vec::new(); index.modules.len()];
        for (module, uncertain) in uncertain_globs.iter_mut().enumerate() {
            for &position in index.globs_of(module) {
                work::add(Work::ReachFormatTokens, 1);
                match index.glob_targets(position) {
                    Ok(targets) if !targets.is_empty() => {
                        for target in targets {
                            readers[target].push(module);
                        }
                    }
                    _ => *uncertain = true,
                }
            }
            if *uncertain {
                queue.push_back(module);
            }
        }
        while let Some(module) = queue.pop_front() {
            for &reader in &readers[module] {
                work::add(Work::ReachFormatTokens, 1);
                if !uncertain_globs[reader] {
                    uncertain_globs[reader] = true;
                    queue.push_back(reader);
                }
            }
        }
        Self {
            disabled,
            uncertain_globs,
        }
    }

    pub(in crate::reach) fn retained_bytes(&self) -> usize {
        size_of::<Self>()
            + self.disabled.capacity() * size_of::<bool>()
            + self.uncertain_globs.capacity() * size_of::<bool>()
    }

    fn sysroot(&self, index: &Index, module: usize, test: bool, leading: bool) -> bool {
        if self.disabled[module]
            || index.no_std(module)
            || index.extern_name(module, "std", test).is_some()
        {
            return false;
        }
        if index.edition(module) < 2018 {
            return false;
        }
        let root = index.modules[module].root;
        if index
            .lookup(root, Namespace::Type, "std")
            .is_some_and(|(bound, _)| {
                bound
                    .keys()
                    .any(|id| index.extern_names.get(id).is_some_and(|name| name != "std"))
            })
        {
            return false;
        }
        leading
            || (index.lookup(module, Namespace::Type, "std").is_none()
                && !index.blocked(module, "std", Namespace::Type, None)
                && !self.uncertain_globs[module])
    }

    fn imported(
        &self,
        index: &Index,
        module: usize,
        test: bool,
        import: &Import,
        allowed: fn(&str) -> bool,
    ) -> bool {
        !import.uncertain
            && endpoint(&import.path, allowed)
            && self.sysroot(index, module, test, import.leading)
    }

    fn glob_clear(
        &self,
        index: &Index,
        module: usize,
        test: bool,
        (name, namespace): (&str, Namespace),
        import: &Import,
    ) -> bool {
        if import.uncertain {
            return false;
        }
        let Ok(walked) = index.walk(
            module,
            &import.path,
            import.leading,
            Namespace::Type,
            Heads::Use { test, own: None },
        ) else {
            return false;
        };
        let mut targets = walked.modules;
        targets.extend(walked.items.keys().flat_map(|id| index.modules_for(*id)));
        !targets.is_empty()
            && targets.into_iter().all(|target| {
                !self.uncertain_globs[target]
                    && index.lookup(target, namespace, name).is_none()
                    && !index.blocked(target, name, namespace, None)
            })
    }

    fn std_unbound(
        &self,
        formats: &Formats,
        mut at: usize,
        index: &Index,
        module: usize,
        test: bool,
    ) -> bool {
        loop {
            work::add(Work::ReachFormatTokens, 1);
            let scope = &formats.scopes[at];
            if scope.std_bound
                || scope.imports.contains_key("std")
                || scope.unknown
                || !scope.globs.iter().all(|import| {
                    self.glob_clear(index, module, test, ("std", Namespace::Type), import)
                })
            {
                return false;
            }
            if matches!(scope.kind, ScopeKind::Module) {
                return true;
            }
            let Some(parent) = scope.parent else {
                return true;
            };
            at = parent;
        }
    }

    pub(in crate::reach) fn standard(
        &self,
        formats: &Formats,
        call: &Call,
        index: &Index,
        module: usize,
        test: bool,
        file: &RelPath,
    ) -> bool {
        if !self.proven(formats, (call, capture_macro), index, module, test, file) {
            return false;
        }
        let mut scope = Some(call.scope);
        while let Some(at) = scope {
            work::add(Work::ReachFormatTokens, 1);
            let here = &formats.scopes[at];
            if let Some(enclosing) = here.enclosing
                && !self.proven(
                    formats,
                    (&formats.calls[enclosing], expression_macro),
                    index,
                    module,
                    test,
                    file,
                )
            {
                return false;
            }
            scope = here.parent;
        }
        true
    }

    fn proven(
        &self,
        formats: &Formats,
        (call, allowed): (&Call, fn(&str) -> bool),
        index: &Index,
        module: usize,
        test: bool,
        file: &RelPath,
    ) -> bool {
        if self.disabled[module] {
            return false;
        }
        let Some(name) = call.path.last() else {
            return false;
        };
        let qualified = endpoint(&call.path, allowed);
        if !qualified && (call.path.len() != 1 || call.leading) {
            return false;
        }
        if qualified && !call.leading && !self.std_unbound(formats, call.scope, index, module, test)
        {
            return false;
        }
        let mut scope = Some(call.scope);
        let mut imported = None;
        let mut lexical_macros = BTreeSet::new();
        let mut outside_module = false;
        while let Some(at) = scope {
            work::add(Work::ReachFormatTokens, 1);
            let here = &formats.scopes[at];
            if here.disabled || (!outside_module && here.unknown) {
                return false;
            }
            if !qualified {
                if let Some(declarations) = here.macros.get(name) {
                    if declarations.iter().any(|&start| start <= call.start) {
                        return false;
                    }
                    lexical_macros.extend(declarations.iter().copied());
                }
                if !outside_module
                    && imported.is_none()
                    && let Some(imports) = here.imports.get(name)
                {
                    if imports.len() != 1
                        || !self.imported(index, module, test, &imports[0], allowed)
                        || (!imports[0].leading
                            && !self.std_unbound(formats, at, index, module, test))
                    {
                        return false;
                    }
                    imported = Some(true);
                }
                if !outside_module
                    && !here.globs.iter().all(|import| {
                        self.glob_clear(index, module, test, (name, Namespace::Macro), import)
                    })
                {
                    return false;
                }
            }
            outside_module |= matches!(here.kind, ScopeKind::Module);
            scope = here.parent;
        }
        if qualified {
            return self.sysroot(index, module, test, call.leading);
        }
        // A settled textual definition later in this same lexical scope does not
        // shadow an earlier call. Other indexed macro definitions always do.
        if let Some((bound, _)) = index.lookup(module, Namespace::Macro, name)
            && bound.keys().any(|id| {
                let item = &index.items[id.0];
                item.file != *file || !lexical_macros.contains(&item.span.end_byte)
            })
        {
            return false;
        }
        let mut ancestor = index.modules[module].parent;
        while let Some(parent) = ancestor {
            work::add(Work::ReachFormatTokens, 1);
            if index.modules[parent].defs.iter().any(|id| {
                let item = &index.items[id.0];
                item.kind == SymbolKind::MacroRules
                    && item.name == name.as_str()
                    && item.file != *file
            }) {
                return false;
            }
            ancestor = index.modules[parent].parent;
        }
        if imported.is_some() {
            return true;
        }
        let positions = index.imports_of(module, name);
        if positions.len() == 1 {
            let position = positions[0];
            let decl = &index.uses[position];
            if let UseKind::Named { segs, .. } = &decl.kind {
                return endpoint(segs, allowed)
                    && index.outside_crate(position).as_deref() == Some("std")
                    && self.sysroot(index, module, test, decl.leading_colon);
            }
        }
        if !allowed(name)
            || !positions.is_empty()
            || self.uncertain_globs[module]
            || index.blocked(module, name, Namespace::Macro, None)
        {
            return false;
        }
        !index.no_std(module) && index.extern_name(module, "std", test).is_none()
    }
}
